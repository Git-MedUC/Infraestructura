---
name: Reporte de bug
about: Informa un error encontrado en el proyecto
---

### Descripción

### Pasos para reproducir

### Resultado esperado

### Evidencia
