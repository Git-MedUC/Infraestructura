---
name: Nueva propuesta de funcionalidad
about: Sugiere una idea para mejorar un proyecto
---

### Descripción

### Solución propuesta

### Impacto
