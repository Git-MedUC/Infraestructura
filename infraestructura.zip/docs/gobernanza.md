## Gobernanza

Define comité directivo, roles y votación de proyectos.