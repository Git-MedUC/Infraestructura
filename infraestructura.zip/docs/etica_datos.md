## Ética y Seguridad de Datos

Uso de datos sintéticos o anonimizados, cumplimiento de normas locales e internacionales.