# Proyecto Médico IA

Descripción breve del proyecto.