# Propuesta de Proyecto

## Título del proyecto:
_(Nombre breve y claro)_

## Problema clínico:
_(Describir el problema médico que se busca resolver)_

## Impacto esperado:
_(Cómo mejora la práctica médica, reduce mortalidad, aumenta eficiencia, etc.)_

## Solución propuesta con IA:
_(Explicar idea técnica: modelo, transcripción, predicción, etc.)_

## Equipo inicial:
- Responsable clínico:
- Responsable técnico:
- Colaboradores:

## Recursos requeridos:
_(Datos, APIs, hardware, software, alianzas)_

## Cronograma inicial:
- Mes 0–1: ideación
- Mes 2–3: prototipo MVP
- Mes 4–6: validación clínica
