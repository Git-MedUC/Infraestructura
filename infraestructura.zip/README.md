# Infraestructura - Grupo Médico IA

Este repositorio contiene los lineamientos, plantillas y normas de gobernanza para el trabajo colaborativo en el desarrollo de software médico con IA.

## Objetivos
- Centralizar plantillas y buenas prácticas.
- Garantizar un flujo de trabajo transparente y reproducible.
- Asegurar el cumplimiento de normas éticas y de seguridad en proyectos médicos.
